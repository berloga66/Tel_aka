<?php
$_localization["serverStoppedByCommand"]="Server is stopped by stopserver command";
$_localization["authOk"]="Thank you! You are logged in! Now you will receive messages from users in this chat.";
$_localization["pleaseEnterManagerPassword"]="Please enter manager password";
$_localization["goingOffline"]="Offline mode. You will no receive new messages! For online mode - send me /online";
$_localization["goingOnline"]="You will receive messages from users again!";
$_localization["youQuit"]="You are logged out. To enter you must enter manager password.";
$_localization["allMessagesAreGoingToChat"]="Now, all your messages will be send to the chat";
$_localization["chat"]="Chat";
$_localization["notAvailible"]="not availible";
$_localization["manager"]="Manager";
$_localization["client"]="Client";
$_localization["fullHistory"]="Full chat history";
$_localization["viewHistory"]="View history";
$_localization["goToOtherChat"]="To enter this chat, type";
$_localization["forAnswerGoToChat"]="To enter this chat, type";
$_localization["otherManagersChat"]="Chat is kept by other manager!";
$_localization["pleaseSelectChatFirst"]="To send message, please select chat first!";
$_localization["serverRestart"]="Server will be restarted in one minute";
$_localization["serverAlreadyRunning"]="Error! Server is already working. Stopped!";
?>