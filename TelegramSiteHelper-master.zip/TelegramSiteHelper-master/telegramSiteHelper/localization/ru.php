<?php
$_localization["serverStoppedByCommand"]="Сервер остановлен по команде stopserver!";
$_localization["authOk"]="Спасибо! Вы авторизованы! Теперь Вы будете получать сообщения от пользователей в этот чат.";
$_localization["pleaseEnterManagerPassword"]="Необходимо ввести пароль для авторизации..";
$_localization["goingOffline"]="Теперь Вы не будете получать сообщения от пользователей.\r\n Чтобы вернуться в онлайн введите команду /online";
$_localization["goingOnline"]="Вы снова будете получать сообщения от пользователей!";
$_localization["youQuit"]="Вы вышли из системы. Для входа необходимо ввести пароль.";
$_localization["allMessagesAreGoingToChat"]="Теперь все ваши сообщения направляются в чат";
$_localization["chat"]="Чат";
$_localization["notAvailible"]="не доступен";
$_localization["manager"]="Менеджер";
$_localization["client"]="Клиент";
$_localization["fullHistory"]="Полная переписка в чАте";
$_localization["viewHistory"]="Посмотреть историю";
$_localization["goToOtherChat"]="Для перехода в этот чат, введите";
$_localization["forAnswerGoToChat"]="Для ответа перейти в чат";
$_localization["otherManagersChat"]="Чат ведет другой менеджер!";
$_localization["pleaseSelectChatFirst"]="Чтобы отправить сообщение сперва надо выбрать чат!";
$_localization["serverRestart"]="Сервер будет перезапущен в течение минуты!";
$_localization["serverAlreadyRunning"]="Ошибка. Сервер уже запущен. Останавливаюсь.";
?>